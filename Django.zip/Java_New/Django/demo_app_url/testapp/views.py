from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def hello(request):
    return HttpResponse("<h1>Hello Testapp App</h1>")

def display(request):
    return HttpResponse("<h2>I'm in display Testapp</h2>")
    


