from django.db import models

# Create your models here.
class Employee(models.Model):
    emp_id=models.IntegerField()
    emp_name=models.CharField(max_length=20)
    emp_addr=models.CharField(max_length=20)
class Meta:
    db_table="Employee"

class Student(models.Model):
    stud_id=models.IntegerField()
    stud_name=models.CharField(max_length=20)
    stud_std=models.IntegerField()
class Meta:
    db_table="Student"
