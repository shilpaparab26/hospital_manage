from django.contrib import admin
from testapp.models import Employee
from testapp.models import Student

# Register your models here.
admin.site.register(Employee)
admin.site.register(Student)
