from django import forms
from testapp.models import Medicine,Customer,Admin,Cart,Order

class MedicineForm(forms.ModelForm):
    class Meta:
        model=Medicine
        fields="__all__"

class CustomerForm(forms.ModelForm):
    class Meta:
        model=Customer
        fields="__all__"
        widgets={
        'custPass':forms.PasswordInput()
        }

class AdminForm(forms.ModelForm):
    class Meta:
        model=Admin
        fields="__all__"

class CartForm(forms.ModelForm):
    class Meta:
        model=Cart
        fields="__all__"

class OrderForm(forms.ModelForm):
    class Meta:
        model=Order
        fields="__all__"
