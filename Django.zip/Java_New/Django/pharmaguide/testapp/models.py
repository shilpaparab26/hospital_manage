from django.db import models

# Create your models here.
class Medicine(models.Model):
    medicineId=models.AutoField(primary_key=True)
    medicineName=models.CharField(max_length=30)
    medicine_manufacture_date=models.CharField(max_length=30)
    medicine_expiry_date=models.CharField(max_length=30)
    medicinePrice=models.FloatField(max_length=15)
    medicineImage=models.ImageField(upload_to='media',default='')
    class Meta:
        db_table="Medicine"

class Customer(models.Model):
    custId=models.AutoField(primary_key=True)
    custName=models.CharField(max_length=30)
    custEmail=models.CharField(max_length=30)
    custPass=models.CharField(max_length=15)
    custCont=models.CharField(max_length=10)
    custAddress=models.CharField(max_length=20)
    class Meta:
        db_table="Customer"

class Admin(models.Model):
    adminName=models.CharField(primary_key=True,max_length=10)
    adminPass=models.CharField(max_length=10)
    class Meta:
        db_table="Admin_SAP"

class Cart(models.Model):
    cartId=models.AutoField(primary_key=True)
    custEmail=models.CharField(max_length=30)
    medicineId=models.IntegerField()
    medicineQuant=models.IntegerField()
    class Meta:
        db_table="Cart"

class Order(models.Model):
    orderId=models.AutoField(primary_key=True)
    custEmail=models.CharField(max_length=30)
    orderDate=models.CharField(max_length=40)
    totalBill=models.IntegerField()
    class Meta:
        db_table="OrderSAP"
