from django.contrib import admin
from testapp.models import Medicine,Customer,Admin,Cart,Order

# Register your models here.
admin.site.register(Medicine)
admin.site.register(Customer)
admin.site.register(Admin)
admin.site.register(Cart)
admin.site.register(Order)


