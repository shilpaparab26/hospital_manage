from django.shortcuts import render,redirect
from django.http import HttpResponse
from testapp.forms import MedicineForm,CustomerForm,AdminForm,CartForm,OrderForm
from testapp.models import Medicine,Customer,Admin,Cart,Order
from django.db import connection,transaction
import json
from django.http import JsonResponse
from django.core import serializers
import datetime
cursor=connection.cursor()

# Create your views here.

def addMedicine(request):
    if request.method=="POST":
        form=MedicineForm(request.POST,request.FILES)
        if form.is_valid():
            try:
                form.save()
                return redirect('Show_medicine')
            except:
                pass
    else:
        form=MedicineForm()
    return render(request,'testapp/addmedicine.html',{'form':form})

def showMedicine(request):
    medicine=Medicine.objects.all()
    return render(request,'testapp/medicinelist.html',{'medicine':medicine})

def shoMedicine(request,medicineId):
    medicine=Medicine.objects.get(medicineId=medicineId) 
    return render(request,'testapp/showinfo.html',{'m':medicine})

def getmedicine(request,medicineId):
    medicine=Medicine.objects.get(medicineId=medicineId)    
    return render(request,'testapp/updatemedicine.html',{'m':medicine})

def deletemedicine(request,medicineId):
    medicine=Medicine.objects.get(medicineId=medicineId)  
    medicine.delete()  
    return redirect('Show_medicine')

def editmedicine(request,medicineId):
    medicine=Medicine.objects.get(medicineId=medicineId)   
    form=MedicineForm(request.POST,instance=medicine)    
    if form.is_valid():
        form.save()
        return redirect('Show_medicine')
    return render(request,'testapp/updatemedicine.html',{'m':medicine})

def addCustomer(request):
    if request.method=="POST":
        form=CustomerForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                return redirect('/showcustomer')
            except:
                pass
    else:
        form=CustomerForm()
    return render(request,'testapp/addcustomer.html',{'form':form})

def showcustomers(request):
    cust=Customer.objects.all()
    return render(request,'testapp/customerlist.html',{'customer':cust})

def getcust(request,custId):
    cust=Customer.objects.get(custId=custId)
    return render(request,'testapp/updatecustomer.html',{'c':cust})

def deletecust(request,custId):
    cust=Customer.objects.get(custId=custId)
    cust.delete()
    return redirect('/showcustomer')

def editcust(request,custId):
    cust=Customer.objects.get(custId=custId)
    form=CustomerForm(request.POST,instance=cust)
    if form.is_valid():
        form.save()
        return redirect('/showcustomer') 
    return render(request,'updatecustomer.html',{'c':cust})  

def login(request):
    return render(request,'testapp/login.html')   

def index(request):
    return render(request,'testapp/index.html')

def about(request):
    return render(request,'testapp/about.html')

def contact(request):
    return render(request,'testapp/contact.html')
    
def search(request,medicineName):
    med=serializers.serialize('json',Medicine.objects.raw("select * from Medicine where medicineName like '%"+medicineName+"%'"))
    medicine=json.loads(med.replace("\'",""))
    return JsonResponse({'medicine':medicine})

def shop(request):
    return render(request,'testapp/shop.html')

def shopsingle(request):
    return render(request,'testapp/shop-single.html')

def doLogin(request):
    if request.method=="POST":
        userId=request.POST.get('userid','')
        passwd=request.POST.get('passwd','')
        utype=request.POST.get('type','')
        print(utype)

        if utype=="user":
            request.session['adminId']=None
            for c in Customer.objects.raw('select * from Customer where custEmail="%s" and custPass="%s"'%(userId,passwd)):
                print('Hi Before if',c)
                if c.custEmail==userId:
                    request.session['userId']=userId
                    return render(request,'testapp/index.html',{'success':'Welcome'+c.custName})
                else:
                    return render(request,'testapp/login.html',{'failure':'login failed!! try again'})

        elif utype=="admin":
            print(utype)
            request.session['userId']=None
            for a in Admin.objects.raw('select * from Admin_SAP where adminName="%s" and adminPass="%s"'%(userId,passwd)):
                if a.adminName==userId:
                    print(userId)
                    request.session['adminId']=userId
                    return render(request,'testapp/index.html',{'success':'login done'})
                else:
                    return render(request,'testapp/login.html',{'failure':'login failed!! try again'})
    else:   
        return render(request,'testapp/login.html')

def addcart(request,medicineId):
    sql='insert into Cart(custEmail,medicineId,medicineQuant)values("%s","%d","%d")'%(request.session['userId'],medicineId,1)
    i=cursor.execute(sql)
    transaction.commit()
    return redirect('Show_medicine')
    
def showcart(request):
    data=Cart.objects.raw('select cartId,medicineName,medicinePrice,medicineQuant from Medicine as m inner join Cart as c on m.medicineId=c.medicineId where custEmail="%s"'%request.session['userId'])
    transaction.commit()
    return render(request,'testapp/mycart.html',{'mycart':data})

def deletecartById(request,cartId):
    cart=Cart.objects.get(cartId=cartId)
    cart.delete()
    return redirect('/Getcart')
    
def placeOrder(request):
    if request.method=="POST":
        price=request.POST.getlist('medicine_price','')
        q=request.POST.getlist('medicine_qnt','')
        total=0.0
        print(price)
        for i in range(len(price)):
            total=total+float(price[i])*float(q[i])
        today=datetime.datetime.now()
        sql='insert into OrderSAP(custEmail,orderDate,totalBill)values("%s","%s","%f")'%(request.session['userId'],str(today),total)
        i=cursor.execute(sql)
        sql='delete from Cart where custEmail="%s"'  %(request.session['userId'])
        i=cursor.execute(sql)
        transaction.commit()
        
        od=Order()
        for o in Order.objects.raw("select * from OrderSAP where custEmail='%s' and orderDate='%s' " %(request.session['userId'],str(today))):
            od=o
            print(od.orderId,od.totalBill)
            return render(request,'testapp/bill.html',{'order':od})
    else:
        pass

def adminchange(request):
    return render(request,'testapp/changepassword.html')
    
def changePass(request):
    if request.method=='POST':
        s=request.session['adminId']
        oldpass=request.POST.get('opassword','')
        newpass=request.POST.get('npassword','')
        for a in Admin.objects.raw('select * from Admin_SAP where adminName="%s" and adminPass="s"'%(s,oldpass)):
            if a.adminName==s:
                sql='update Admin_SAP set adminPass="%s" where adminName="%s"' %(newpass,s)
                i=cursor.execute(sql)
                transaction.commit()
                session_keys=list(request.session.keys())
                for key in session_keys:
                    del request.session[key]
                return redirect('login')
        else:
            return redirect(request,'testapp/changepassword.html',{'failure':'old password doesnt match'})

def logout(request):
     session_keys=list(request.session.keys())
     for key in session_keys:
        del request.session[key]
     return render(request,'testapp/index.html',{'success':'logout successfully!!'})
    
def addadmin():
    sql='insert into Admin_SAP(adminName,adminPass)values("%s","%s")'%("admin","root123");
    i=cursor.execute(sql)
    transaction.commit()


