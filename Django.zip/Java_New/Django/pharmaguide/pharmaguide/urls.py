"""pharmaguide URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.conf import settings,urls
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.urls import path
from testapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('Addmedicine',views.addMedicine),
    path('allmedicine/<int:medicineId>',views.shoMedicine),
    path('Show_medicine',views.showMedicine),
    path('showcustomer/',views.showcustomers),
    path('addcustomer/',views.addCustomer),
    path('updatecustomer/',views.editcust),
    path('getcustomer/<int:custId>',views.getcust),
    path('deletecustomer/<int:custId>',views.deletecust),
    path('editcustomer/<int:custId>',views.editcust),
    path('Login_page',views.login),
    path('getmedicine/<int:medicineId>',views.getmedicine),
    path('deletemedicine/<int:medicineId>',views.deletemedicine),
    path('editmedicine/<int:medicineId>',views.editmedicine),
    path('Index',views.index),
    path('about/',views.about),
    path('contact',views.contact),
    path('shop/',views.shop),
    path('shop-single/',views.shopsingle),
    path('dologin',views.doLogin),
    path('addtocart/<int:medicineId>',views.addcart),
    path('Getcart',views.showcart),
    path('deletecartbyid/<int:cartId>',views.deletecartById),
    path('placeorder',views.placeOrder),
    path('log',views.logout),
    path('Search/<str:medicineName>',views.search),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
