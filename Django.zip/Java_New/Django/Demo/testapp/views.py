from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
class Test:
    def hello(self,request):
        return HttpResponse("<h1 >Hello Coder</h1>")

    def display(self,request):
        return HttpResponse("<h1>Coder Technologies</h1>")
