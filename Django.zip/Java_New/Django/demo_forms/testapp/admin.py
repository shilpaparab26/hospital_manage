from django.contrib import admin
from testapp.models import Login

# Register your models here.
admin.site.register(Login)



