from django.shortcuts import render
from testapp.forms import LoginForm
# Create your views here.

def index(request):
    login_form=LoginForm()
    return render(request,'testapp/demo.html',{'form':login_form})
    
