from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request,"testapp/demo.html")
def show2(request):
    return render(request,"testapp/demo1.html")
