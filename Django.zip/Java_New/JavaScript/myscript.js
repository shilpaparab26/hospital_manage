document.getElementById("demo").innerHTML="hello coder";
var x=document.getElementsByTagName("p")
document.write(x[0].innerHTML)
var y=document.getElementsByClassName("A")
document.write(y[0].innerHTML)

function myfun()
{
document.write("Hello Coder")
alert("Hello")
}
