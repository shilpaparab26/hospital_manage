function validate()
{
var name=document.getElementById("cname").value
var passwd=document.getElementById("cpasswd").value
var addr=document.getElementById("caddr").value
var contact=document.getElementById("ccon").value
alert(name)
if(name=="")
{
document.getElementById("cnameerr").innerHTML="Please enter name";
}
if(passwd=="")
{
document.getElementById("cpasswderr").innerHTML="Please enter password";
}
if(addr=="")
{
document.getElementById("caddrerr").innerHTML="Please enter address";
}
if(contact=="")
{
document.getElementById("contacterr").innerHTML="Please enter Contact";
}
}



